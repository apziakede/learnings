/****** Object:  Database [GiversDB]    Script Date: 5/10/2024 6:19:33 PM ******/
use master
CREATE DATABASE [GiversDB]
 